input_string = input('Enter a string: \n')
string_length = len(input_string)
if string_length > 0:
    print(string_length)
else:
    print('This string is empty.')
