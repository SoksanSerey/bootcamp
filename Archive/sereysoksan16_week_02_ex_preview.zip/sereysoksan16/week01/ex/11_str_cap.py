input_string = input('Enter a string: ')
string_length = len(input_string)
if string_length > 0:
    print(input_string.upper())
else:
    print('This string is empty.')
