print('Welcome to Kirirom!')
