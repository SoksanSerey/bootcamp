def list_set(list1):
    # this function will take a list as parameter and return a list with unique value only
    return set(list1)


# ran_list = ['456', '123', '789', '123', 'abc', 'abc', 'def']
# print(list_set(ran_list))
