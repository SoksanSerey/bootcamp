def tuple_first(tuple1):
    # this function will take a tuple as a parameter and return the first value
    return tuple1[0]


# ran_tuple = ('abc', 123)
# print(tuple_first(ran_tuple))
