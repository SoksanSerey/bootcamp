def list_sort(list1):
    # this function will take a list as parameter and return a sorted list
    return sorted(list1)


# ran_list = [4, 2, 19, 50, 49, 48, 1, 2, 3, 4, 5]
# print(list_sort(ran_list))
