def current_date():
    import datetime

    # this function is written to show the current date
    return str(datetime.date.today())


# print(current_date())
