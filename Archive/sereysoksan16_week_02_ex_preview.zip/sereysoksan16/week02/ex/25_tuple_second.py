def tuple_second(tuple1):
    # this function will take a tuple as input and return the second value of that tuple as output
    return tuple1[1]


# ran_tuple = ('abc', 123)
# print(tuple_second(ran_tuple))
