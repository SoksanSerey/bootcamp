def fun_split(ran_string):
    # this function will take a random string as input
    list1 = ran_string.split()
    # this will split the string by white space and write it into a list
    return list1
    # this will return a list for output


# ran_text = 'Hello! It’s me again!'
# print(fun_split(ran_text))
