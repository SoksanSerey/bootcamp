def list_sort_set(list1):
    # this function will take a list as parameter and return a sorted list with unique values only
    return sorted(set(list1))


# ran_list = [4, 2, 19, 50, 49, 48, 1, 2, 3, 4, 5]
# print(list_sort_set(ran_list))
