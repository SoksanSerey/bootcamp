def fun_calc(a, b):
    # this function will take 2 parameters as input and sum those 2 value together
    # result fo that
    print(a, '+', b, '=', a + b)
    return a + b
    # it return the total value of a + b


# A = 5
# B = 15
# print(fun_calc(A, B))
