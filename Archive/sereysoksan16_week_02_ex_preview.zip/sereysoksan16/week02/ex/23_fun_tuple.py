def fun_tuple(a, b):
    tuple1 = (a, b)
    # insert the value into the tuple
    return tuple1
    # return the tuple as an output


# A = 'abc'
# B = 123
# print(fun_tuple(A, B))
