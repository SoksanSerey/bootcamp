# this function will take 2 dimensional list as parameter
def sudoku(board):
    dummy_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    region = 0
    if len(board) == 9:
        count = 0
        inner_ele_count = 0
        new_list = []
        for i in range(0, 9):

            # check whether the list has 9 inner list or not
            if len(board[i]) == 9:
                count += 1

        # check whether the inner list has 9 elements each or not
        if count == 9:
            for i in range(0, 9):

                # check whether is the number is duplicate or not
                if len(board[i]) == len(set(board[i])):

                    # check whether the number that input must be in 1-9
                    for j in range(0, 9):
                        if board[i][j] in dummy_list:
                            inner_ele_count += 1
                        else:
                            return 'Invalid Format'
                else:
                    return 'Not Finished'
            if inner_ele_count == 81:

                # check whether the vertical value is unique or not
                for i in range(0, 9):
                    temp_list = []
                    for j in range(0, 9):
                        temp_list.append(board[j][i])
                    if len(temp_list) == len(set(temp_list)):
                        continue
                    else:
                        return 'Not Finished'
            else:
                return 'Invalid Format'
            temp_list = []
            for i in range(0, 3):
                for j in range(0, 3):
                    temp_list.append(board[i][j])
            new_list.append(temp_list)
            temp_list = []
            for i in range(0, 3):
                for j in range(3, 6):
                    temp_list.append(board[i][j])
            new_list.append(temp_list)
            temp_list = []
            for i in range(0, 3):
                for j in range(6, 9):
                    temp_list.append(board[i][j])
            new_list.append(temp_list)
            temp_list = []
            for i in range(3, 6):
                for j in range(0, 3):
                    temp_list.append(board[i][j])
            new_list.append(temp_list)
            temp_list = []
            for i in range(3, 6):
                for j in range(3, 6):
                    temp_list.append(board[i][j])
            new_list.append(temp_list)
            temp_list = []
            for i in range(3, 6):
                for j in range(6, 9):
                    temp_list.append(board[i][j])
            new_list.append(temp_list)
            temp_list = []
            for i in range(6, 9):
                for j in range(0, 3):
                    temp_list.append(board[i][j])
            new_list.append(temp_list)
            temp_list = []
            for i in range(6, 9):
                for j in range(3, 6):
                    temp_list.append(board[i][j])
            new_list.append(temp_list)
            temp_list = []
            for i in range(6, 9):
                for j in range(6, 9):
                    temp_list.append(board[i][j])
            new_list.append(temp_list)
            for i in range(0, 9):
                if len(new_list[i]) == len(set(new_list[i])):
                    region += 1
                else:
                    continue
            if region == 9:
                return 'Finished'
            else:
                return 'Not Finished'
        else:
            return 'Invalid Format'
    else:
        return 'Invalid Format'


board_1 = [
    [5, 3, 4, 6, 7, 8, 9, 1, 2],
    [6, 7, 2, 1, 9, 5, 3, 4, 8],
    [1, 9, 8, 3, 4, 2, 5, 6, 7],
    [8, 5, 9, 7, 6, 1, 4, 2, 3],
    [4, 2, 6, 8, 5, 3, 7, 9, 1],
    [7, 1, 3, 9, 2, 4, 8, 5, 6],
    [9, 6, 1, 5, 3, 7, 2, 8, 4],
    [2, 8, 7, 4, 1, 9, 6, 3, 5],
    [3, 4, 5, 2, 8, 6, 1, 7, 9]
    ]
res = sudoku(board_1)
if res != "Finished":
    print("KO - BOARD_1: should have 'Finished' but got '" + res + "' instead")
else:
    print("OK - BOARD_1")

#Finished

board_2 = [
    [5, 3, 4, 6, 7, 8, 9, 1, 2],
    [6, 7, 2, 1, 9, 5, 3, 4, 8],
    [1, 9, 8, 3, 4, 2, 5, 6, 7],
    [8, 5, 9, 7, 6, 1, 4, 2, 3],
    [4, 2, 6, 8, 5, 3, 7, 9, 1],
    [7, 1, 3, 9, 2, 4, 8, 5, 6],
    [9, 6, 1, 5, 3, 7, 2, 8, 4],
    [2, 8, 7, 4, 1, 9, 6, 3, 5],
    [3, 4, 5, 2, 8, 6, 1, 7, 3]
    ]
res = sudoku(board_2)
if res != "Not Finished":
    print("KO - BOARD_2: should have 'Not Finished' but got '" + res + "' instead")
else:
    print("OK - BOARD_2")

board_3 = [
    [5, 3, 4, 6, 7, 8, 9, 1, 2],
    [6, 7, 2, 1, 9, 5, 3, 4, 8],
    [1, 9, 8, 3, 4, 2, 5, 6, 7],
    [8, 5, 9, 7, 6, 1, 4, 2, 3],
    [4, 2, 6, 8, 5, 3, 7, 9, 1],
    [7, 1, 3, 9, 2, 4, 8, 5, 6],
    [9, 6, 1, 5, 3, 7, 1, 1, 1],
    [2, 8, 7, 4, 1, 9, 1, 1, 1],
    [3, 4, 5, 2, 8, 6, 1, 1, 1]
    ]
res = sudoku(board_3)
if res != "Not Finished":
    print("KO - BOARD_3: should have 'Not Finished' but got '" + res + "' instead")
else:
    print("OK - BOARD_3")

board_4 = [
    [5, 3, 4, 6, 7, 8, 9, 1, 2],
    [6, 7, 2, 1, 9, 5, 3, 4, 8],
    [1, 9, 8, 3, 4, 2, 5, 6, 7],
    [8, 5, 9, 7, 6, 1, 4, 2, 3],
    [4, 2, 6, 8, 5, 3, 7, 9],
    [7, 1, 3, 9, 2, 4, 8, 5, 6],
    [9, 6, 1, 5, 3, 7, 2, 8, 4],
    [2, 8, 7, 4, 1, 9, 6, 3, 5],
    [3, 4, 5, 2, 8, 6, 1, 7, 9]
    ]
res = sudoku(board_4)
if res != "Invalid Format":
    print("KO - BOARD_4: should have 'Invalid Format but got '" + res + "' instead")
else:
    print("OK - BOARD_4")

board_5 = [
    [5, 3, 4, 6, 7, 8, 9, 1, 2],
    [6, 7, 2, 1, 9, 5, 3, 4, 8],
    [1, 9, 8, 3, 4, 2, 5, 6, 7],
    [8, 5, 9, 7, 6, 1, 4, 2, 3],
    [4, 2, 6, 8, 5, 3, 7, 9, 1],
    [7, 1, 3, 9, 2, 4, 8, 5, 6],
    [9, 6, 1, 5, 3, 7, 1, 1, 1],
    [2, 8, 7, 4, 1, 9, 1, 1, 1],
    [3, 4, 5, 2, 8, 6, 1, 1, 1],
    [3, 4, 5, 2, 8, 6, 1, 1, 1]
    ]
res = sudoku(board_5)
if res != "Invalid Format":
    print("KO - BOARD_5: should have 'Invalid Format but got '" + res + "' instead")
else:
    print("OK - BOARD_5")


board_6 = [
    [5, 3, 4, 6, 7, 8, 9, 1, 2],
    [6, 7, 2, 1, 9, 5, 3, 4, 8],
    [1, 9, 8, 3, 4, 2, 5, 6, 7],
    [8, 5, 9, 7, 6, 1, 4, 2, 3],
    [4, 2, 6, 8, 5, 3, 7, 9, 1],
    [7, 1, 3, 9, 2, 4, 8, 5, 6],
    [9, 6, 1, 5, 3, 7, 2, 8, 4],
    [2, 8, 7, 4, 1, 9, 6, 3, 5]
    ]
res = sudoku(board_6)
if res != "Invalid Format":
    print("KO - BOARD_6: should have 'Invalid Format but got '" + res + "' instead")
else:
    print("OK - BOARD_6")
