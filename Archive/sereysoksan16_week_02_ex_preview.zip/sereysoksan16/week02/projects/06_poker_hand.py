

def poker_hand(player1, player2):
    from collections import defaultdict

    card_rank = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13,
                 'A': 14}
    player1_list = player1.split()
    player2_list = player2.split()

    def check_royal(hand):
        values = [i[0] for i in hand]
        if set(values) == {'A', 'T', 'K', 'Q', 'J'}:
            return True
        else:
            return False

    def check_flush(hand):
        suits = [i[1] for i in hand]
        if len(set(suits)) == 1:
            return True
        else:
            return False

    def check_royal_flush(hand):
        if check_royal(hand) and check_flush(hand):
            return True
        else:
            return False

    def check_straight(hand):
        values = [i[0] for i in hand]
        values_count = defaultdict(lambda: 0)
        for v in values:
            values_count[v] += 1
        # print(values_count)
        rank_values = [card_rank[i] for i in values]
        # print(rank_values)
        values_range = max(rank_values) - min(rank_values)
        if len(set(values_count.values())) == 1 and values_range == 4:
            return True
        else:
            if set(values) == set(['A', '2', '3', '4', '5']):
                return True
            return False

    def check_straight_flush(hand):
        if check_flush(hand) and check_straight(hand):
            return True
        else:
            return False

    def check_four_of_a_kind(hand):
        values = [i[0] for i in hand]
        values_count = defaultdict(lambda: 0)
        for v in values:
            values_count[v] += 1
        if sorted(values_count.values()) == [1, 4]:
            return True
        else:
            return False

    def check_three_of_a_kind(hand):
        values = [i[0] for i in hand]
        values_count = defaultdict(lambda: 0)
        for v in values:
            values_count[v] += 1
        if set(values_count.values()) == set([3, 1]):
            return True
        else:
            return False

    def check_full_house(hand):
        values = [i[0] for i in hand]
        values_count = defaultdict(lambda: 0)
        for v in values:
            values_count[v] += 1
        if sorted(values_count.values()) == [2, 3]:
            return True
        else:
            return False

    def check_two_pair(hand):
        values = [i[0] for i in hand]
        values_count = defaultdict(lambda: 0)
        for v in values:
            values_count[v] += 1
        if sorted(values_count.values()) == [1, 2, 2]:
            return True
        else:
            return False

    def check_one_pair(hand):
        values = [i[0] for i in hand]
        values_count = defaultdict(lambda: 0)
        for v in values:
            values_count[v] += 1
        if sorted(values_count.values()) == [1, 1, 1, 2]:
            return True
        else:
            return False

    # not completed yet for the highest value
    def check_high_card(hand):
        price = 0
        values = [i[0] for i in hand]
        values_count = defaultdict(lambda: 0)
        for v in values:
            values_count[v] += 1
        rank_values = [card_rank[i] for i in values]
        for i in rank_values:
            price += i
        return price

    def check_hand(hand):
        if check_royal_flush(hand):
            return 79
        elif check_straight_flush(hand):
            return 78
        elif check_four_of_a_kind(hand):
            return 77
        elif check_full_house(hand):
            return 76
        elif check_flush(hand):
            return 75
        elif check_straight(hand):
            return 74
        elif check_three_of_a_kind(hand):
            return 73
        elif check_two_pair(hand):
            return 72
        elif check_one_pair(hand):
            return 71
        elif check_high_card(hand):
            return 70

    player1_value = check_hand(player1_list)
    player2_value = check_hand(player2_list)
    if player1_value > player2_value:
        return 'Player 1 WIN'
    elif player2_value > player1_value:
        return 'Player 2 WIN'
    else:
        return 'Tie'


player1_card = 'AH KS QH JH TH'
player2_card = 'AS KH QC JC TH'
print(poker_hand(player1_card, player2_card))
